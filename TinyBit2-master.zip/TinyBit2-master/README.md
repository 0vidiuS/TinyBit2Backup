# Tiny:bit

Extension for Yahboom Tiny:bit V2.0.3

## License

MIT

## Supported targets

* for PXT/microbit
(The metadata above is needed for package search.)
